package com.miu.moviedetailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDetailServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
