package com.miu.moviedetailservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieDetailServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieDetailServiceApplication.class, args);
	}

}
